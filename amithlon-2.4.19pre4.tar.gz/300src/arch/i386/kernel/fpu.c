#include <linux/kernel.h>

void boot_init_fpu(void)
{
}
