#include <linux/kernel.h>
#include <linux/init.h>

void out_of_line_bug(void)
{
	printk(KERN_ALERT "Out-of-line bug called!\n");
	for(;;){ asm("hlt"); }
}
