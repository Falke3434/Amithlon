#define MACHVEC_PLATFORM_NAME		hp
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_hpzx1.h>
#include <asm/machvec_init.h>
